A clock I made in Blender some time ago.

Animated Yes
Rigged Yes
Lowpoly (game-ready) Yes
Geometry Subdivision ready
Polygons 196
Vertices 227
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Overlapping

There are three different versions for blender.
-Blender Game Engine
-Cycles Rendering
-Clock with animation constraints setup for animating the time

Demo-Videos

Blender Game Engine:
https://www.youtube.com/watch?v=AkR8oqtmYQc

Cycles Rendering: 
https://www.youtube.com/watch?v=VFkE29ABj_4

Clock with animation constraints setup for animating the time:
https://www.youtube.com/watch?v=WwCH66Wzf-c


Homepage: http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/
Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010

